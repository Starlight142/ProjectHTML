﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Aspx_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btncal_Click(object sender, EventArgs e)
    {
        if (Convert.ToDecimal(txtheight.Text) > 200 || Convert.ToDecimal(txtweight.Text) > 100)
        {
            Response.Write("ยักษ์");
        }
        else
        {
            Response.Write("มนุษย์");
        }
    }
}
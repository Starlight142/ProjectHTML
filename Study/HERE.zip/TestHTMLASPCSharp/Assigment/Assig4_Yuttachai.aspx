﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Assig4_Yuttachai.aspx.cs" Inherits="Aspx_Default" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            ส่วนสูง:
            <asp:TextBox ID="txtheight" runat="server"></asp:TextBox>
            <br />
            น้ำหนัก:
            <asp:TextBox ID="txtweight" runat="server"></asp:TextBox>
            <br />
            <br />
            <asp:Button ID="btncal" runat="server" Text="คำนวณ" OnClick="btncal_Click" />
        </div>
    </form>
</body>
</html>

﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="FormMain.aspx.cs" Inherits="SessionMultiview_FormMain" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <style type="text/css">
        .auto-style11 {
            text-align: center;
            width: 250px;
            background-color: #33CCFF;
            height: 30px;
        }
        .auto-style18 {
            width: 400px;
            background-color: #FF66FF;
        }
        .auto-style22 {
            background-color: #66FF66;
            width: 350px;
        }
        .auto-style23 {
            text-align: center;
            background-color: #FF9933;
            width: 250px;
        }
        .auto-style24 {
            width: 400px;
            background-color: #FF66FF;
            text-align: center;
            height: 30px;
        }
        .auto-style25 {
            width: 250px;
            background-color: #33CCFF;
        }
        .auto-style29 {
            text-align: center;
            width: 350px;
            background-color: #66FF66;
        }
        </style>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <asp:Label ID="Label1" runat="server" Text="กรุณาเลือกอาหารหรือเครื่องดื่ม:"></asp:Label>
        &nbsp;&nbsp;&nbsp;
            <asp:DropDownList ID="DropDownList1" runat="server" AutoPostBack="True" OnSelectedIndexChanged="DropDownList1_SelectedIndexChanged">
                <asp:ListItem>-กรุณาเลือก-</asp:ListItem>
                <asp:ListItem>อาหาร</asp:ListItem>
                <asp:ListItem>เครื่องดื่ม</asp:ListItem>
            </asp:DropDownList>
            <br />
            <br />
            <asp:MultiView ID="MultiView1" runat="server">
                <asp:View ID="Meat" runat="server">
                    <table class="auto-style8">
                        <tr>
                            <td class="auto-style24">รายการอาหาร</td>
                            <td class="auto-style23">ราคา</td>
                            <td class="auto-style11">จำนวน</td>
                            <td class="auto-style29">ราคาทั้งหมด</td>
                        </tr>
                        <tr>
                            <td class="auto-style18">
                                <asp:CheckBox ID="ckOne" Text="ข้าวขาหมู" AutoPostBack="True" runat="server" OnCheckedChanged="ckOne_CheckedChanged" />
                            </td>
                            <td class="auto-style23">
                                <asp:Label ID="lblPrice1" runat="server" Text="50"></asp:Label>
                            </td>
                            <td class="auto-style25">
                                <asp:TextBox ID="txtQN1" runat="server" Width="250px" AutoPostBack="True" Visible="False" OnTextChanged="txtQN1_TextChanged"></asp:TextBox>
                            </td>
                            <td class="auto-style22">
                                <asp:TextBox ID="txtTotal1" runat="server" ReadOnly="True"  Width="350px" Visible="False" AutoPostBack="True" BackColor="#999999"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style18">
                                <asp:CheckBox ID="ckTwo" Text="ข้าวผัดปู" AutoPostBack="True" runat="server" OnCheckedChanged="ckTwo_CheckedChanged" />
                            </td>
                            <td class="auto-style23">
                                <asp:Label ID="lblPrice2" runat="server" Text="60"></asp:Label>
                            </td>
                            <td class="auto-style25">
                                <asp:TextBox ID="txtQN2" runat="server" Width="250px" AutoPostBack="True" Visible="False" OnTextChanged="txtQN2_TextChanged"></asp:TextBox>
                            </td>
                            <td class="auto-style29">
                                <asp:TextBox ID="txtTotal2" runat="server" ReadOnly="True" Width="350px" Visible="False" AutoPostBack="True" BackColor="#999999"></asp:TextBox>
                            </td>
                        </tr>
                    </table>
                </asp:View>
                <asp:View ID="Drink" runat="server">
                </asp:View>
                <br />
            </asp:MultiView>
            <br />
            <br />
            <asp:Button ID="btnClick" runat="server" Text="รวมรายการ" Visible="False" OnClick="btnClick_Click" />
        </div>
    </form>
</body>
</html>

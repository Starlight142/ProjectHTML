﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="RequireFile.aspx.cs" Inherits="TestVaildate_RequireFile" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <asp:Label ID="Lable1" runat="server" Text="Username:"></asp:Label>
        &nbsp;&nbsp;&nbsp;
            <asp:TextBox ID="txtUsername1" runat="server" Width="280px"></asp:TextBox>
            <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtUsername1" ErrorMessage="**" ForeColor="Red"></asp:RequiredFieldValidator>
            <br />
            <asp:Label ID="Lable2" runat="server" Text="Password:"></asp:Label>
        &nbsp;&nbsp;&nbsp;
            <asp:TextBox ID="txtPassword1" runat="server" Width="280px"></asp:TextBox>
            <br />
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <asp:Button ID="btnSave" runat="server" OnClick="btnSave_Click" Text="Button" />
        </div>
    </form>
</body>
</html>
